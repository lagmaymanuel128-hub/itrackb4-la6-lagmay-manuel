<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DishController;

// Order matters: fixed words (featured, filter) must come BEFORE the {id} wildcard.
Route::get('/dishes', [DishController::class, 'index'])->name('dishes.index');
Route::get('/dishes/featured', [DishController::class, 'featured'])->name('dishes.featured');
Route::get('/dishes/filter/{origin?}', [DishController::class, 'filter'])->name('dishes.filter');
Route::get('/dishes/{id}', [DishController::class, 'show'])->name('dishes.show');
