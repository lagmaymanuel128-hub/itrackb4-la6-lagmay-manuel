<!DOCTYPE html>
<html>
<head>
    <title>{{ $dish['name'] }} - Bicolano Dishes</title>
</head>
<body>
    <h1>{{ $dish['name'] }}</h1>
    <p>Prepared by: LAGMAY JR. MANUEL T.</p>

    <table border="1" cellpadding="8">
        <tr><th>ID</th><td>{{ $dish['id'] }}</td></tr>
        <tr><th>Main Ingredient</th><td>{{ $dish['main_ingredient'] }}</td></tr>
        <tr><th>Origin</th><td>{{ $dish['origin'] }}</td></tr>
    </table>

    <p><a href="{{ route('dishes.index') }}">Back to list</a></p>
</body>
</html>
