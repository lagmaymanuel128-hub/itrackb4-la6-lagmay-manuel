# LA3 - Detail Pages, Route Parameters and Order

Prepared by: LAGMAY JR. MANUEL T.

## Q1. Order of the featured route and the detail route, and what happens if they are swapped

_Write 2-3 sentences in your own words._

## Q2. What happens when someone visits an id that does not exist, and what did you write to make that happen?

_Write 2-3 sentences in your own words._

## Q3. Why do your links use route names instead of typed URLs? Give one concrete thing that would break otherwise.

_Write 2-3 sentences in your own words._
