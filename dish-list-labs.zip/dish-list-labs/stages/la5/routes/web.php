<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DishController;

// Custom routes go BEFORE the resource line, or /dishes/{dish} would catch them first.
Route::get('/dishes/featured', [DishController::class, 'featured'])->name('dishes.featured');
Route::get('/dishes/filter/{origin?}', [DishController::class, 'filter'])->name('dishes.filter');

// One line replaces the individual list and detail routes.
// Only the two implemented actions are registered.
Route::resource('dishes', DishController::class)->only(['index', 'show']);
