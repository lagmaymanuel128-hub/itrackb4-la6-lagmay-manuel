<?php

namespace App\Http\Controllers;

class DishController extends Controller
{
    public function index()
    {
        $dishes = [
            ['name' => 'Bicol Express', 'main_ingredient' => 'Pork and Sili', 'origin' => 'Naga City'],
            ['name' => 'Laing', 'main_ingredient' => 'Dried Taro Leaves', 'origin' => 'Camarines Sur'],
            ['name' => 'Pinangat', 'main_ingredient' => 'Taro Leaves and Coconut Milk', 'origin' => 'Camarines Sur'],
            ['name' => 'Kinunot', 'main_ingredient' => 'Shark or Stingray', 'origin' => 'Albay'],
            ['name' => 'Sinantol', 'main_ingredient' => 'Santol Fruit', 'origin' => 'Camarines Norte'],
            ['name' => 'Sili Ice Cream', 'main_ingredient' => 'Chili and Cream', 'origin' => 'Camarines Sur'],
        ];

        return view('dishes.index', ['dishes' => $dishes]);
    }
}
