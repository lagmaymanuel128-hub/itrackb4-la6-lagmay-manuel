<!DOCTYPE html>
<html>
<head>
    <title>Bicolano Dishes</title>
</head>
<body>
    <h1>Bicolano Dishes</h1>
    <p>Prepared by: LAGMAY JR. MANUEL T.</p>

    <table border="1" cellpadding="8">
        <tr>
            <th>Dish</th>
            <th>Main Ingredient</th>
            <th>Origin</th>
        </tr>

        @foreach ($dishes as $dish)
            <tr>
                <td>{{ $dish['name'] }}</td>
                <td>{{ $dish['main_ingredient'] }}</td>
                <td>{{ $dish['origin'] }}</td>
            </tr>
        @endforeach
    </table>
</body>
</html>
