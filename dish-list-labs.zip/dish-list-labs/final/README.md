# Bicolano Dishes - ITRACKB4 Laboratory Activities (LA2 to LA6)

Prepared by: LAGMAY JR. MANUEL T.

One Laravel project that grew across five activities: list page (LA2), detail/featured/filter routes (LA3),
one Blade layout with Bootstrap (LA4), a resource controller (LA5), and two query-string filters (LA6).

## LA6 Answers

### Q1. You added a second filter without adding a single route. Why was no new route needed? (What does the router look at?)

_Write 3-4 sentences in your own words._

### Q2. If both filters were route parameters, what would the URL for "category only, no origin" look like, and why?

_Write 3-4 sentences in your own words._

### Q3. Your nav link stays marked on a detail page and when a filter is applied. Which one needed a change to your pattern, and why did the other need nothing?

_Write 3-4 sentences in your own words._

### Q4. Why did you delete the old filter method but keep the empty store and update methods?

_Write 3-4 sentences in your own words._
