@php
    // 'dishes*' matches /dishes, /dishes/3 (longer path) and ignores ?query strings.
    $inDishes = request()->is('dishes*') && ! request()->is('dishes/featured');
    $inFeatured = request()->is('dishes/featured');
@endphp

<nav class="nav bg-light px-3">
    <a class="nav-link {{ $inDishes ? 'active fw-bold' : '' }}" href="{{ route('dishes.index') }}">Dishes</a>
    <a class="nav-link {{ $inFeatured ? 'active fw-bold' : '' }}" href="{{ route('dishes.featured') }}">Featured</a>
</nav>
