@extends('layouts.app')

@section('title', 'Bicolano Dishes')

@section('content')
    <div class="mb-2">
        <strong>Origin:</strong>
        <a href="{{ route('dishes.index', ['category' => $category]) }}"
           class="btn btn-sm {{ $origin ? 'btn-outline-secondary' : 'btn-secondary' }}">Any</a>
        @foreach ($origins as $o)
            <a href="{{ route('dishes.index', ['origin' => $o, 'category' => $category]) }}"
               class="btn btn-sm {{ $origin === $o ? 'btn-primary' : 'btn-outline-primary' }}">{{ $o }}</a>
        @endforeach
    </div>

    <div class="mb-3">
        <strong>Category:</strong>
        <a href="{{ route('dishes.index', ['origin' => $origin]) }}"
           class="btn btn-sm {{ $category ? 'btn-outline-secondary' : 'btn-secondary' }}">Any</a>
        @foreach ($categories as $c)
            <a href="{{ route('dishes.index', ['origin' => $origin, 'category' => $c]) }}"
               class="btn btn-sm {{ $category === $c ? 'btn-primary' : 'btn-outline-primary' }}">{{ $c }}</a>
        @endforeach
    </div>

    <p>
        Active filters:
        origin = <strong>{{ $origin ?? 'any' }}</strong>,
        category = <strong>{{ $category ?? 'any' }}</strong>
        <a href="{{ route('dishes.index') }}" class="btn btn-sm btn-danger ms-2">Clear all</a>
    </p>

    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Dish</th>
                <th>Main Ingredient</th>
                <th>Origin</th>
                <th>Category</th>
                <th>Tag</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($dishes as $id => $dish)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td><a href="{{ route('dishes.show', $id) }}">{{ $dish['name'] }}</a></td>
                    <td>{{ $dish['main_ingredient'] }}</td>
                    <td>{{ $dish['origin'] }}</td>
                    <td>{{ $dish['category'] }}</td>
                    <td>
                        @if ($dish['origin'] === 'Camarines Sur')
                            <span class="badge bg-success">Camarines Sur</span>
                        @else
                            <span class="text-muted">-</span>
                        @endif
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="6">No dishes match these filters. Try clearing one of them.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
@endsection
