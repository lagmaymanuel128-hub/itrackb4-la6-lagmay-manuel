<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DishController;

// Custom routes go BEFORE the resource line.
Route::get('/dishes/featured', [DishController::class, 'featured'])->name('dishes.featured');

// Old filter URL kept alive: send visitors (and bookmarks) to the new query-string version.
Route::get('/dishes/filter/{origin?}', function ($origin = null) {
    return redirect()->route('dishes.index', ['origin' => $origin]);
});

Route::resource('dishes', DishController::class)->only(['index', 'show']);
