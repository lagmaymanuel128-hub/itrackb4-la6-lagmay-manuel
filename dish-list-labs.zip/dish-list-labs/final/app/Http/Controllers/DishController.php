<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DishController extends Controller
{
    private function getDishes()
    {
        return [
            1 => ['id' => 1, 'name' => 'Bicol Express', 'main_ingredient' => 'Pork and Sili', 'origin' => 'Naga City', 'category' => 'Meat'],
            2 => ['id' => 2, 'name' => 'Laing', 'main_ingredient' => 'Dried Taro Leaves', 'origin' => 'Camarines Sur', 'category' => 'Vegetable'],
            3 => ['id' => 3, 'name' => 'Pinangat', 'main_ingredient' => 'Taro Leaves and Coconut Milk', 'origin' => 'Camarines Sur', 'category' => 'Vegetable'],
            4 => ['id' => 4, 'name' => 'Kinunot', 'main_ingredient' => 'Shark or Stingray', 'origin' => 'Albay', 'category' => 'Seafood'],
            5 => ['id' => 5, 'name' => 'Sinantol', 'main_ingredient' => 'Santol Fruit', 'origin' => 'Camarines Norte', 'category' => 'Vegetable'],
            6 => ['id' => 6, 'name' => 'Sili Ice Cream', 'main_ingredient' => 'Chili and Cream', 'origin' => 'Camarines Sur', 'category' => 'Dessert'],
        ];
    }

    /**
     * Display a listing of the resource, optionally filtered by ?origin= and ?category=
     */
    public function index(Request $request)
    {
        $allDishes = $this->getDishes();

        // null means "no filter on this field"
        $origin = $request->query('origin', null);
        $category = $request->query('category', null);

        // array_filter keeps the array keys, so the detail links still get the right id
        $dishes = array_filter($allDishes, function ($dish) use ($origin, $category) {
            return (! $origin || $dish['origin'] === $origin)
                && (! $category || $dish['category'] === $category);
        });

        return view('dishes.index', [
            'dishes' => $dishes,
            'origin' => $origin,
            'category' => $category,
            'origins' => array_values(array_unique(array_column($allDishes, 'origin'))),
            'categories' => array_values(array_unique(array_column($allDishes, 'category'))),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $dishes = $this->getDishes();
        if (!isset($dishes[$id])) {
            abort(404);
        }
        return view('dishes.show', ['dish' => $dishes[$id], 'id' => $id]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    /**
     * Extra method (not one of the seven): featured dish.
     */
    public function featured()
    {
        $dishes = $this->getDishes();
        return view('dishes.show', ['dish' => $dishes[1], 'id' => 1]);
    }
}
